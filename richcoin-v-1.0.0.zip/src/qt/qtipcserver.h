#ifndef QTIPCSERVER_H
#define QTIPCSERVER_H

// Define Richcoin-Qt message queue name
#define RICHCOINURI_QUEUE_NAME "RichcoinURI"

void ipcInit();

#endif // QTIPCSERVER_H
