 
 
 
 
 
#ifndef RICHCOIN_IRC_H
#define RICHCOIN_IRC_H

void ThreadIRCSeed(void* parg);

extern int nGotIRCAddresses;

#endif
